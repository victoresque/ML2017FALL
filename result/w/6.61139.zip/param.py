# Paths
data_path = 'data'
preproc_path = 'preproc'
result_path = 'result'

# Constants
hours_per_day = 24

# Data-specific constants
n_days = 240
n_categories = 18
pm25_category_id = 9

# Adjustable
feature_len = 9 # need pre-process after changing
categories = [2, 3, 7, 8, 9, 16] # need pre-process after changing
cat_2nd = [3, 4, 5]
cat_all2nd = [3, 4]
cat_3rd = []
all_2nd_lookback = 2

local_valid = False
n_valid = 100
Lambda = 1e2


valid_fold = 20
use_gradient_descent = False
n_epoch = 10000
eta0 = 1000

# Derived constants
x_len = feature_len * len(categories)