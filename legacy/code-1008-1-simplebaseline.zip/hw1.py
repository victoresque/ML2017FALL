import pandas as pd
import numpy as np
from param import *
from util import *

test_data = pd.read_csv('data/test.csv', header=None).replace('NR', '0').values
w = pd.read_csv('result/w.csv', header=None).values.T

n_rows = test_data.shape[0]//n_categories
test_X = np.zeros((0, feature_len))
for i in range(n_rows):
    test_X = np.append(test_X, test_data[i*n_categories:(i+1)*n_categories, -feature_len:], axis=0)

test_X = to_homogeneous(flatten(extract(test_X.astype(np.float))))
test_y = np.dot(w, test_X.T)
pd.DataFrame([['id_' + str(i), test_y[0][i]] for i in range(n_rows)], columns=['id', 'value']) \
  .to_csv('result/result.csv', index=False)