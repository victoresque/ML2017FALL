import numpy as np
from param import *

def rms(x):
    return np.sqrt(np.mean(np.square(x)))

def rmse(x, y):
    return rms(y - x)

def gradient(w, X, y, reg=0):
    return np.sum(2 * np.dot(y.T - np.dot(w, X.T), -X), axis=0) + 2 * reg * w

def extract(X):
    X_ext = np.zeros((0, feature_len))
    for i in range(X.shape[0] // n_categories):
        for ci in range(len(categories)):
            x = X[i*n_categories + categories[ci]]
            X_ext = np.append(X_ext, [x], axis=0)
            if cat_order[ci] == 2:
                X_ext = np.append(X_ext, np.square([x]), axis=0)
    return X_ext

def flatten(X):
    feat_rows = np.sum(cat_order)
    X_flat = np.zeros((0, feat_rows * feature_len))
    for i in range(X.shape[0] // feat_rows):
        X_flat = np.append(X_flat, [X[i * feat_rows:(i + 1) * feat_rows, :].flatten()], axis=0)
    return X_flat

# converting [x] to [1 x]
def to_homogeneous(X):
    return np.insert(X, 0, [1], axis=1)