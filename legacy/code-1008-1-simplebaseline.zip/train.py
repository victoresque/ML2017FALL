import pandas as pd
import numpy as np
from param import *
from util import *

# Splitting training X and y
t_rmse, v_rmse = [], []

train_X = pd.read_csv('preproc/pre_X.csv', header=None).values
train_y = pd.read_csv('preproc/pre_y.csv', header=None).values
train_data = np.append(train_X, train_y, axis=1)

for i in range(n_valid):
    print('.', end='', flush=True)
    n_rows = train_data.shape[0]
    n_cols = train_data.shape[1]

    if local_valid:
        valid_X = train_X[0:(n_rows//valid_fold), :]
        valid_y = train_y[0:(n_rows//valid_fold), :]
        train_X = train_X[(n_rows//valid_fold):n_rows, :]
        train_y = train_y[(n_rows//valid_fold):n_rows, :]

    w = np.zeros((1, train_X.shape[1]))
    if use_gradient_descent:
        # Gradient descent using Adagrad
        g_norm_sum = 0.0
        for i in range(n_epoch):
            eta, g = eta0/np.sqrt(i+1), gradient(w, train_X, train_y, Lambda)
            g_norm_sum += np.square(np.linalg.norm(g))
            w = w - eta * g / np.sqrt(g_norm_sum/(i+1))
            print('Epoch', str(i)+': rmse =', rmse(np.dot(w, train_X.T), train_y.T))
    else:
        w = np.dot(np.dot(np.linalg.inv(np.dot(train_X.T, train_X) + Lambda * np.identity(train_X.shape[1])),
                          train_X.T), train_y).T
        t_rmse.append(rmse(np.dot(w, train_X.T), train_y.T))

    test_data = pd.read_csv('data/test.csv', header=None).replace('NR', '0').values
    n_rows = test_data.shape[0]//n_categories
    test_X = np.zeros((0, feature_len))
    for i in range(n_rows):
        test_X = np.append(test_X, test_data[i*n_categories:(i+1)*n_categories, -feature_len:], axis=0)

    if local_valid:
        test_X = valid_X
        test_y = np.dot(w, test_X.T)
        v_rmse.append(rmse(test_y, valid_y.T))
    else:
        test_X = to_homogeneous(flatten(extract(test_X.astype(np.float))))
        test_y = np.dot(w, test_X.T)
        pd.DataFrame([['id_' + str(i), test_y[0][i]] for i in range(n_rows)], columns=['id', 'value']) \
          .to_csv('result/result.csv', index=False)

    pd.DataFrame(w.T).to_csv('result/w.csv', header=None, index=False)
    if not local_valid:
        break

if local_valid:
    print('')
    print('----------------------------------------')
    print('   Training   mean =', np.mean(t_rmse))
    print('   Training   std  =', np.std(t_rmse))
    print('   Validation mean =', np.mean(v_rmse))
    print('   Validation std  =', np.std(v_rmse))
    print('   Difference      =', np.mean(v_rmse)-np.mean(t_rmse))
    print('----------------------------------------')