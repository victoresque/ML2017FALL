import pandas as pd
import numpy as np
import os
from param import *

train_data = pd.read_csv('data/train.csv', encoding='big5')\
               .drop(['日期', '測站', '測項'], axis=1)\
               .replace('NR', '0').values

train_x = np.zeros((0, x_len))
train_y = np.zeros((0, 1))

for month in range(months_per_year):
    month_offset = month * n_days * n_categories
    for day in range(n_days):
        day_offset = month_offset + day * n_categories
        for time in range(hours_per_day):
            pm25_row = day_offset + pm25_category_id + (time+feature_len>=hours_per_day)*n_categories
            pm25_col = (time+feature_len) % hours_per_day
            if pm25_row > month_offset + n_days * n_categories:
                break
            x = np.zeros((1, x_len))
            y = np.array([[train_data[pm25_row][pm25_col]]])
            for ci in range(len(categories)):
                for i in range(feature_len):
                    row = day_offset + categories[ci] + (time+i>=hours_per_day)*n_categories
                    col = (time+i) % hours_per_day
                    x[0][ci*feature_len + i] = train_data[row][col]
            train_x, train_y = np.append(train_x, x, axis=0), np.append(train_y, y, axis=0)

pd.DataFrame(np.append(train_x, train_y, axis=1))\
  .to_csv('preproc/train.csv', index=False, header=False)

