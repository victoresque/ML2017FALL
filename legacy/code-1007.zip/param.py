# Constants
months_per_year = 12
hours_per_day = 24

# Data-specific constants
n_days = 20
n_categories = 18
pm25_category_id = 9

# Adjustable
feature_len = 9 # need pre-process after changing
categories = [8, 9] # need pre-process after changing
cat_2nd = []
cat_all2nd = []
lookback_2nd = 0
lookback_all_2nd = 2
cat_3rd = []

local_valid = True
n_valid = 10
Lambda = 8e2

valid_fold = 20
use_gradient_descent = False
eta0 = 1
n_epoch = 10000

# Derived constants
x_len = feature_len * len(categories)